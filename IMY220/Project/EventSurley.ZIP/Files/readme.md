<h1>Event website</h1>
<p>
  This website is my project for IMY 220, it is currently only in its second
  ittaration and I am busy with the last itteration
</p>

<h2>How to use the website</h2>
<ol>
  <li>
    Download all the files from the repository or you can Click here to go to a
    Google drive link (Do not change the any file names or the linking will be
    affected)
  </li>
  <li>
    Set up localhost (skip if localhost is setup)
    <ul>
      <li>Donwload XAMPP <a href="">Here</a></li>
      <li>Copy the files under your new XAMPP directory called htdocs/</li>
      <li>Launch the XAMPP app</li>
      <li>Start the Apache and MySQL modules</li>
    </ul>
  </li>
  <li>
    Set up the database
    <ul>
      <li>
        Go to
        <a href="http://localhost/phpmyadmin/">http://localhost/phpmyadmin/</a>
      </li>
      <li>Create a new Database called "eventsureley"</li>
      <li>Click on the database called eventsureley and navigate to import</li>
      <li>Click on choose file and select the file called eventsureley.sql</li>
    </ul>
  </li>
  <li>
    Launch the website by typeing in the following url
    <a href="http://localhost/Files/index.html"
      >http://localhost/Files/index.html</a
    >/li>
  </li>
</ol>

<h3>Login details</h3>
<p>The login details are as follows:</p>

<ul>
  <li>Email : carlisworldoftanks@gmail.com</li>
  <li>Password: 12345678</li>
</ul>
<ul>
  <li>Email : maxisworldchamp@gmail.com</li>
  <li>Password: lewis</li>
</ul>
