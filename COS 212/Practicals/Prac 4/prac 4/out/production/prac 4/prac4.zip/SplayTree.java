public class SplayTree<T extends Comparable<T>> {

    public TreeNode<T> root;

    public SplayTree() {
        // Your code here...
    }

    /**
     * Returns true if the key exists in the tree, otherwise false
     */
    public Boolean contains(T key) {
        // Your code here...
        if (root == null) {
            return false;
        }
        TreeNode<T> p = root;
        while (p != null) {
            if (key.equals(p.key)) {
                return true;
            } else if (key.compareTo(p.key) < 0) {
                p = p.left;
            } else {
                p = p.right;
            }
        }
        return false;
    }

    /**
     * Insert the given key into the tree.
     * Duplicate keys should be ignored.
     * No Splaying should take place.
     */
    public void insert(T key) {
        if (root == null) {
            root = new TreeNode(key);
            return;
        }
        if ((contains(key))) {
            return;
        }
        addingdammnode(root, key);
        // Your code here...
    }

    public TreeNode<T> addingdammnode(TreeNode ptr, T key) {
        if (ptr == null) {
            ptr = new TreeNode(key);
            return ptr;
        }


        if (ptr.key.compareTo(key) < 0)
             ptr.right = addingdammnode(ptr.right, key);
        else if (ptr.key.compareTo(key) > 0)
            ptr.left = addingdammnode(ptr.left, key);
        return ptr;
    }

    /**
     * Return the Predecessor of the given key.
     * If the given key does not exist return null.
     * If the given key does not have a Predecessor, return null.
     */
    public T findPredecessor(T key) {
        // Your code here...
        if(root == null){
            return null;
        }
        if(!contains(key)){
            return null;
        }

        letsGoPre(root,key);
        if(pre == null){
            return null;
        }else{
            return (T) pre.key;
        }
    }

    TreeNode pre ;
    TreeNode suc;
    int counting;

    private void letsGoPre(TreeNode temp, T key) {
        if (temp == null)
            return;
        counting=0;
        while (temp != null) {

            if (temp.key.equals(key)) {

                if (temp.right != null) {
                    counting++;
                    String RS = "inside of temp right";
                    suc = temp.right;
//                    System.out.println(RS);
                    String WR = "in while loop right";
                    while (suc.left != null) {
//                        System.out.println(WR);
                        counting++;
                        suc = suc.left;
                    }
//                    System.out.println(counting++);
                }

                if (temp.left != null) {
                    counting++;
                    String LS = "left side of temp";
                    pre = temp.left;
                   String Wl = "left while loop";
//                    System.out.println(LS);
                    while (pre.right != null) {
//                        System.out.println(Wl);
                        counting++;
                        pre = pre.right;
                    }
//                    System.out.println(counting);
                }
                return;
            }

            else if (temp.key.compareTo(key) < 0) {
                counting++;
                String KOS = "key on other side";
                pre = temp;
//                System.out.println(counting);
                temp = temp.right;
//                System.out.println(KOS);
            }

            else {
                counting++;
                String KOOS = "key on other other side";
                suc = temp;
//                System.out.println(counting);
                temp = temp.left;
//                System.out.println(KOOS);
            }
        }
    }

    /**`
     * Move the accessed key closer to the root using the splaying strategy.
     * If the key does not exist, insert it without splaying
     */
    public void access(T key) {
        // Your code here...
        if (root == null) {
            return;
        }
        if (!contains(key)) {
            insert(key);
            return;
        }
        DiSplayingItBaby(root, key);

    }

    //Helpers
    /*private TreeNode DiSplayingItBaby(TreeNode nodie, T val) {
        if (nodie == null) {
            return nodie;
        }

        if(nodie.key.compareTo(val) < 0){
            if (nodie.right == null)
                return nodie;

            if (nodie.right.key.compareTo(val) > 0) {
//                TreeNode dammnodie;
//                dammnodie = DiSplayingItBaby(nodie.right.left, val);
//                nodie.right.left = dammnodie;
                nodie.right.left = DiSplayingItBaby(nodie.right.left, val);
                if (nodie.right.left != null)
                    nodie.right = RightRotateDamBoy(nodie.right);
            } else if (nodie.right.key.compareTo(val) < 0) {
//                TreeNode dammnodie;
//                dammnodie = DiSplayingItBaby(nodie.right.right, val);
//                nodie.right.right = dammnodie;
                nodie.right.right = DiSplayingItBaby(nodie.right.right, val);
                nodie = LeftRotateDamBoy(nodie);
            }
            if (nodie.right == null) {
                return nodie;
            } else {
                return LeftRotateDamBoy(nodie);
            }
        }else{
            if (nodie.left == null) {
                return nodie;
            }

            if (nodie.left.key.compareTo(val) > 0) {
//                TreeNode dammnodie;
//                dammnodie = DiSplayingItBaby(nodie.left.left, val);
//                nodie.left.left = dammnodie;
                nodie.left.left = DiSplayingItBaby(nodie.left.left, val);
                nodie = RightRotateDamBoy(nodie);
            } else if (nodie.left.key.compareTo(val) < 0) {
//                TreeNode dammnodie;
//                dammnodie = DiSplayingItBaby(nodie.left.right, val);
//                nodie.left.right = dammnodie;
                nodie.left.right = DiSplayingItBaby(nodie.left.right, val);
                if (nodie.left.right != null) {
                    nodie.left = LeftRotateDamBoy(nodie.left);
                }
            }
            if (nodie.left == null) {
                return nodie;
            } else {
                return RightRotateDamBoy(nodie);
            }
        }
    }*/

    /*--------------------redo of splay --------------------*/

    private TreeNode DiSplayingItBaby(TreeNode nodie, T val) {
        if (nodie == null || nodie.key == val)
            return nodie;

        // Key lies in left subtree
        if (nodie.key.compareTo(val) > 0)
        {
            if (nodie.left == null) {
                return nodie;
            }

            if (nodie.left.key.compareTo(val) > 0) {
                TreeNode dammnodie;
                dammnodie = DiSplayingItBaby(nodie.left.left, val);
                nodie.left.left = dammnodie;
                nodie = RightRotateDamBoy(nodie);
            } else if (nodie.left.key.compareTo(val) < 0) {
                TreeNode dammnodie;
                dammnodie = DiSplayingItBaby(nodie.left.right, val);
                nodie.left.right = dammnodie;
                if (nodie.left.right != null) {
                    nodie.left = LeftRotateDamBoy(nodie.left);
                }
            }
            if (nodie.left == null) {
                return nodie;
            } else {
                return RightRotateDamBoy(nodie);
            }
        }
        else
        {
            if (nodie.right == null)
                return nodie;

            if (nodie.right.key.compareTo(val) > 0) {
                TreeNode dammnodie;
                dammnodie = DiSplayingItBaby(nodie.right.left, val);
                nodie.right.left = dammnodie;
                if (nodie.right.left != null)
                    nodie.right = RightRotateDamBoy(nodie.right);
            } else if (nodie.right.key.compareTo(val) < 0) {
                TreeNode dammnodie;
                dammnodie = DiSplayingItBaby(nodie.right.right, val);
                nodie.right.right = dammnodie;
                nodie = LeftRotateDamBoy(nodie);
            }
            if (nodie.right == null) {
                return nodie;
            } else {
                return LeftRotateDamBoy(nodie);
            }
        }
    }

    private TreeNode RightRotateDamBoy(TreeNode ptr) {
        TreeNode L = ptr.left;
        TreeNode LR = L.right;

        root = L;
        L.right = ptr;
        ptr.left = LR;
        return L;
    }

    private TreeNode LeftRotateDamBoy(TreeNode ptr) {
        TreeNode R = ptr.right;
        TreeNode RL = R.left;

        root = R;
        R.left = ptr;
        ptr.right = RL;
        return R;
    }
}