var router = (app,fs) => {
    // code
}

dataFile = "data.json";

module.exports = router;
