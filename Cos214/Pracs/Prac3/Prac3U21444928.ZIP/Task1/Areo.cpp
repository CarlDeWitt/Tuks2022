#include "Areo.h"

Areo::Areo(int bbps): AeratedChocolate("Areo", 9.00, bbps) {
    cout << "Areo constructor" << endl;
}