#include "DiaryMilk.h"

DiaryMilk::DiaryMilk(bool slab): Choclate("DiaryMilk", 25.00, slab) {
    cout << "DiaryMilk constructor" << endl;
}