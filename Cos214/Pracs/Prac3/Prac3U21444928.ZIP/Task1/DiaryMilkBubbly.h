#ifndef DIARYMILKBUBBLY_H
#define DIARYMILKBUBBLY_H
#include "AeratedChocolate.h"
using namespace std;
#include <string>

class DiaryMilkBubbly : public AeratedChocolate {
    public:
        DiaryMilkBubbly(int);
        // ~DiaryMilkBubbly();
};

#endif
