#ifndef MILKYBAR_H
#define MILKYBAR_H
#include "Choclate.h"
using namespace std;
#include <string>

class MilkyBar : public Choclate {
    public:
        MilkyBar(bool);
        // ~MilkyBar();
};

#endif
