#ifndef Lindt_H
#define Lindt_H
#include "Choclate.h"
using namespace std;
#include <string>

class Lindt : public Choclate {
    public:
        Lindt(bool);
        // ~Lindt();
};

#endif
