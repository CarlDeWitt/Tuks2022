#ifndef DIARYMILK_H
#define DIARYMILK_H
#include "Choclate.h"
using namespace std;
#include <string>

class DiaryMilk : public Choclate{
   public:
   DiaryMilk(bool);
   // ~DiaryMilk();
};

#endif
