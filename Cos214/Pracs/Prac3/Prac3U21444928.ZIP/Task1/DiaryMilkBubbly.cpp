#include "DiaryMilkBubbly.h"

DiaryMilkBubbly::DiaryMilkBubbly(int bbps): AeratedChocolate("DiaryMilkBubbly", 5.00, bbps) {
    cout << "an DiaryMilkBubbly was created " << endl;
}