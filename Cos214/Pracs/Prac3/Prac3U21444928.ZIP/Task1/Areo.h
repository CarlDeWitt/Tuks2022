#ifndef AREO_H
#define AREO_H
#include "AeratedChocolate.h"
using namespace std;
#include <string>

class Areo : public AeratedChocolate {
    public:
        Areo(int);
        // ~Areo();
};

#endif
