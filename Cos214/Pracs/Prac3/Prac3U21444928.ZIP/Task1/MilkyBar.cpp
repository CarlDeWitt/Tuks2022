#include "MilkyBar.h"

MilkyBar::MilkyBar(bool slab): Choclate("MilkyBar", 32.00, slab) {
    cout << "an DiaryMilk was created " << endl;
}