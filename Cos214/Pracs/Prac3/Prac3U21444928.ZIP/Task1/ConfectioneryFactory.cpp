#include "ConfectioneryFactory.h"

ConfectioneryFactory::ConfectioneryFactory()
{
}