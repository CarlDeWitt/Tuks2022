#include "Lindt.h"

Lindt::Lindt(bool slab): Choclate("Lindt", 50.00, slab) {
    cout << "Lindt constructor" << endl;
}