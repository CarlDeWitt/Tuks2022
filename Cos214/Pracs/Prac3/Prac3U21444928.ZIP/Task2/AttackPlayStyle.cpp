#include "AttackPlayStyle.h"

AttackPlayStyle::AttackPlayStyle() : PlayStyle()
{
}

string AttackPlayStyle::attack()
{
	return "decides life is better than death and leaves the battle.";
}
