#ifndef PHYSICALATTACKPLAYSTYLE_H
#define PHYSICALATTACKPLAYSTYLE_H
#include "PlayStyle.h"

class PhysicalAttackPlayStyle : public PlayStyle
{

public:
	PhysicalAttackPlayStyle();
	string attack();
};

#endif
