#include "BattleState.h"
BattleState::BattleState() {}
string BattleState::getBattleState()
{
    return battlestate;
}
BattleState::~BattleState() {}
