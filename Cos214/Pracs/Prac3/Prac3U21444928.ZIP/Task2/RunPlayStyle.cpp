#include "RunPlayStyle.h"

RunPlayStyle::RunPlayStyle() : PlayStyle()
{
}

string RunPlayStyle::attack()
{
	return "decides life is better than death and leaves the battle.";
}
