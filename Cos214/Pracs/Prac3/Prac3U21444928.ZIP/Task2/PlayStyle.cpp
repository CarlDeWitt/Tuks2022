#include "PlayStyle.h"
PlayStyle::PlayStyle() {}
