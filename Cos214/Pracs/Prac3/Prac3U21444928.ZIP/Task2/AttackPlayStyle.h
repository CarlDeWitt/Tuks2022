#ifndef ATTACKPLAYSTYLE_H
#define ATTACKPLAYSTYLE_H
#include "PlayStyle.h"

class AttackPlayStyle : public PlayStyle
{

public:
	AttackPlayStyle();
	string attack();
};

#endif
